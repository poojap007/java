
import React from "react";
//importing all lab components
import GroceryList from "./components/GroceryList";
import Car from "./components/Car";
import Phone from "./components/Phone";
import SweetsList from "./components/SweetsList";
import Electronics from "./components/Electronics";
import CanteenMenu from "./components/CanteenMenu";
import JuiceList from "./components/JuiceList";
import Restaurant from "./components/Restaurant";
import TempleList from "./components/TempleList";
import TailorShop from "./components/TailorShop";
import Fruits from "./components/Fruits";
import TelevisionManager from "./components/TelivisionManager";
import MarriageForm from "./components/MarriageForm";
import BakingItemsForm from "./components/BakingItemsForm";
function App() {
  return (
    <div className="container">
      <GroceryList items={["Rice", "Wheat", "Sugar", "Milk", "Oil"]} />
      <Car brand="Toyota" model="Fortuner" color="Black" year="2022" />
       <Phone />
       <SweetsList/>
       <Electronics/>
       <CanteenMenu/>
       <JuiceList/>
       <Restaurant/>
       <TempleList/>
       <TailorShop/>
       <Fruits/>
       <TelevisionManager/>
       <MarriageForm/>
       <BakingItemsForm/>
    </div>
  );
}
export default App;